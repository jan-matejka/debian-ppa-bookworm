# GCR Hello App

A small ~2MB image, type

```
podman-compose up
```

then open your browser on [http://localhost:8080/](http://localhost:8080/)

