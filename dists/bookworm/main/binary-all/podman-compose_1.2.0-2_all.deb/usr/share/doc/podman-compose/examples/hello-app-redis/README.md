# GCR Hello App Redis

A 6-node redis cluster using [Bitnami](https://github.com/bitnami/bitnami-docker-redis-cluster)
with a [simple hit counter](https://github.com/GoogleCloudPlatform/kubernetes-engine-samples/tree/main/hello-app-redis) that persists on that redis cluster

```
podman-compose up
```

then open your browser on [http://localhost:8080/](http://localhost:8080/)


